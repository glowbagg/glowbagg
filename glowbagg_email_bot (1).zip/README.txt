🧠 Glowbagg Email Bot - IA Multilingüe

Este bot revisa el correo de Glowbagg (infoglowbagg@gmail.com), detecta el idioma del mensaje y responde automáticamente con inteligencia artificial.

✅ Funciona con Gmail (IMAP/SMTP)
✅ Usa ChatGPT (OpenAI GPT-4)
✅ Multilingüe: responde en el idioma del cliente
✅ Ideal para atención al cliente 24/7

📦 Archivos incluidos:
- glowbagg_email_bot.py → El script principal
- requirements.txt → Librerías necesarias

🚀 Cómo usar:
1. Asegúrate de tener Python 3 instalado
2. Instala las dependencias:
   pip install -r requirements.txt
3. Ejecuta el bot:
   python glowbagg_email_bot.py

¡Y listo! Cada minuto revisará nuevos correos y responderá automáticamente.
